import http.server
import socketserver
import os
import socket

PORT = 8080
DIRECTORY = os.path.join(os.path.dirname(__file__), "app", "src", "main", "assets", "www")

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

def get_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
    except Exception:
        ip = '127.0.0.1'
    finally:
        s.close()
    return ip

if __name__ == '__main__':
    local_ip = get_ip()
    print("=" * 60)
    print("🚗 تم تشغيل خادم ملاحة مصر 3D بنجاح!")
    print(f"📱 لتجربة التطبيق مباشرة على هاتفك الأندرويد عبر الواي فاي:")
    print(f"👉 افتح متصفح هاتفك واكتب الرابط: http://{local_ip}:{PORT}")
    print(f"💻 أو على الكمبيوتر: http://localhost:{PORT}")
    print("=" * 60)
    
    with socketserver.TCPServer(("", PORT), Handler) as httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nتم إيقاف الخادم.")
